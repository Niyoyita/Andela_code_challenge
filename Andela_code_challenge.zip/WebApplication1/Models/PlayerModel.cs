﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    [DataContract]
    public class PlayerModel
    {
        [DataMember(Name = "player_id")]
        public string Id { get; set; }

        [DataMember(Name = "entry_id")]
        public string entry_id { get; set; }

        [DataMember(Name = "name")]
        public string Name { get; set; }

        [DataMember(Name = "position")]
        public string Position { get; set; }

        [DataMember(Name = "yds")]
        public string yds { get; set; }
        [DataMember(Name = "att")]
        public string att { get; set; }
        [DataMember(Name = "tds")]
        public string tds { get; set; }
        [DataMember(Name = "fum")]
        public string fum { get; set; }
    }
}
