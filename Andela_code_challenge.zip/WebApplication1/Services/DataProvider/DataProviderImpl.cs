﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Services.DataProvider
{
    public class DataProviderImpl : IDataProvider
    {
        public static TimeSpan Timeout = TimeSpan.FromSeconds(30);
        public string id;
        public  PlayerModel GetPlayerById(string id)
        {
           var reslt = GetReturnedResult(id);
            //creating fo method that will ascyn to return the result.
            PlayerModel plmode = new PlayerModel();
            plmode.Name = reslt.GetAwaiter().GetResult().Name;
            plmode.Id = reslt.GetAwaiter().GetResult().Id;
            plmode.Position = reslt.GetAwaiter().GetResult().Position;

            return plmode;
        }
      
        public List<PlayerModel> GetLatestPlayer()
        {
            List<PlayerModel> plmodeList = new List<PlayerModel>();
            var reslt = GetReturnedResultLatest();
            foreach(var asyReslt in reslt.GetAwaiter().GetResult())
            {
                if(asyReslt != null)
                {
                    PlayerModel plmode = new PlayerModel();
                    plmode.Name = asyReslt.Name;
                    plmode.Id = asyReslt.Id;
                    plmode.Position = asyReslt.Position;
                    plmode.att = asyReslt.att;
                    plmode.entry_id = asyReslt.entry_id;
                    plmode.fum = asyReslt.fum;
                    plmode.tds = asyReslt.tds;
                    plmode.yds = asyReslt.yds;
                    plmodeList.Add(plmode);

                }
            }
            
            return plmodeList;
        }
        public async Task<PlayerModel> GetReturnedResult(string id)
        {
            var playerReslt = new PlayerModel();
            await Task.Run(() =>
            {
                try
                {
                    var handler = new HttpClientHandler()
                    {
                        AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate
                    };
                    using (var client = new HttpClient(handler))
                    {
                        client.Timeout = Timeout;
                        var response = client.GetAsync("https://gist.githubusercontent.com/RichardD012/a81e0d1730555bc0d8856d1be980c803/raw/3fe73fafadf7e5b699f056e55396282ff45a124b/basic.json").Result;
                        var stringData = response.Content.ReadAsStringAsync().Result;
                        var dataResponse = JsonConvert.DeserializeObject<DataResponseModel>(stringData, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto });
                        foreach (var player in dataResponse.Rushing)
                        {
                            if (player.Id.Equals(id))
                            {
                                playerReslt = player;
                            }
                        }
                        foreach (var player in dataResponse.Passing)
                        {
                            if (player.Id.Equals(id))
                            {
                                playerReslt = player;
                            }
                        }
                        foreach (var player in dataResponse.Receiving)
                        {
                            if (player.Id.Equals(id))
                            {
                                playerReslt = player;
                            }
                        }
                        foreach (var player in dataResponse.Receiving)
                        {
                            if (player.Id.Equals(id))
                            {
                                playerReslt = player;
                            }
                        }
                        foreach (var player in dataResponse.Kicking)
                        {
                            if (player.Id.Equals(id))
                            {
                                playerReslt = player;
                            }
                        }
                        //this is for missing player
                        if (dataResponse.Missing != null)
                        {
                            foreach (var player in dataResponse.Missing)
                            {
                                if (player.Id.Equals(id))
                                {
                                    playerReslt = player;
                                }
                            }
                        }

                    }
                }
                catch (Exception e)
                {

                }
                
            });

            return playerReslt;
        }
        public async Task<List<PlayerModel>> GetReturnedResultLatest()
        {
            List<PlayerModel> listPlayerModel = new List<PlayerModel>();
            await Task.Run(() =>
            {
                try
                {
                    var handler = new HttpClientHandler()
                    {
                        AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate
                    };
                    using (var client = new HttpClient(handler))
                    {
                        client.Timeout = Timeout;
                        var response = client.GetAsync("https://gist.githubusercontent.com/RichardD012/a81e0d1730555bc0d8856d1be980c803/raw/3fe73fafadf7e5b699f056e55396282ff45a124b/output.json").Result;
                        var stringData = response.Content.ReadAsStringAsync().Result;
                        var dataResponse = JsonConvert.DeserializeObject<DataResponseModel>(stringData, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto });

                        if (dataResponse.Rushing != null)
                        {
                            foreach (var player in dataResponse.Rushing)
                            {
                                listPlayerModel.Add(player);
                            }
                        }
                        if (dataResponse.Passing != null)
                        {
                            foreach (var player in dataResponse.Passing)
                            {
                                listPlayerModel.Add(player);
                            }
                        }
                        if (dataResponse.Receiving != null)
                        {
                            foreach (var player in dataResponse.Receiving)
                            {
                                listPlayerModel.Add(player);
                            }
                        }
                        if (dataResponse.Missing != null)
                        {
                            foreach (var player in dataResponse.Missing)
                            {
                                listPlayerModel.Add(player);
                            }
                        }
                        if (dataResponse.Kicking != null)
                        {
                            foreach (var player in dataResponse.Kicking)
                            {
                                listPlayerModel.Add(player);
                            }
                        }
                        //this is for missing player
                        if (dataResponse.Missing != null)
                        {
                            foreach (var player in dataResponse.Missing)
                            {

                                listPlayerModel.Add(player);
                            }
                        }


                    }
                }
                catch(Exception e)
                {

                }
               
            });

            return listPlayerModel;
        }
       
    }
}
