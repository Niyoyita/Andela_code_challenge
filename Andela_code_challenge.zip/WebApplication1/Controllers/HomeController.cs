﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication1.Models;
using WebApplication1.Services.DataProvider;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private IDataProvider _dataProvider;
        public HomeController(IDataProvider dataProvider)
        {
            _dataProvider = dataProvider ?? throw new ArgumentNullException(nameof(dataProvider));
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Player(string id)
        {
            var result = new PlayerModel();
             result = _dataProvider.GetPlayerById(id);
             return Json(result);
        }

        [HttpGet]
        [DisableRequestSizeLimit]
        public  IActionResult Players(string ids)
        {
            var returnList = new List<PlayerModel>(); 
            
                var idList = ids.Split(',');
               
                foreach (var id in idList)
                {
                    returnList.Add(_dataProvider.GetPlayerById(id));
                }
            return Json(returnList.Select(o => new { o.Id, o.Name,o.Position }).Distinct());
        }
        [HttpGet]
        public IActionResult LatestPlayers(string ids)
        {
            var result = _dataProvider.GetLatestPlayer();
            return Json(result);
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
